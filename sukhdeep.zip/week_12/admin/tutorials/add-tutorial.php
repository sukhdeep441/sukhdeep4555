<?php
// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $title = $_POST['tutorial_title'];
    $description = $_POST['tutorial_content']; 
    
    // Insert into database
    $sql = "INSERT INTO tutorials (title, description) VALUES ('$title', '$description')"; 
    if ($conn->query($sql) === TRUE) {
        header("Location: ../admin-index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
