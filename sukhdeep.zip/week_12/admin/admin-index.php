<?php
// Start session
session_start();




// Include config file
require_once '../dbinfo.php';




// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}








// Fetch the background image URL from the database
$background_image_query = "SELECT header_background_image FROM banner WHERE id = 1";
$background_image_result = mysqli_query($con, $background_image_query);
$background_image_row = mysqli_fetch_assoc($background_image_result);
$background_image_url = $background_image_row['header_background_image'];




// Fetch team members from the database
$team_members_query = "SELECT * FROM our_team";
$team_members_result = mysqli_query($con, $team_members_query);




// Fetch story from the database
$story_query = "SELECT * FROM our_story";
$story_result = mysqli_query($con, $story_query);




?>








<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }




        header {
            background-size: cover;
            background-position: center;
            color: #fff;
            text-align: center;
            padding: 50px 0; /* Increase the top and bottom padding */
            /* Add a dark shadow */
            box-shadow: inset 0 0 2000px rgba(0, 0, 0, 0.5);
        }




        nav ul {
            list-style-type: none;
            padding: 0;
        }
        nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }




        main {
            padding: 20px;
        }




        h1 {
            margin-top: 0;
        }




        section {
            background-color: white;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }




        ul {
            padding: 0;
            list-style-type: none;
        }




        ul li {
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }




        ul li a {
            color: #007bff;
            text-decoration: none;
            margin-left: 10px;
        }




        form {
            margin-top: 20px;
        }




        label {
            display: block;
            margin-bottom: 5px;
        }




        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }




        input[type="submit"] {
            padding: 8px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }




        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>




<body>
    <header style="background-image: url('<?php echo $background_image_url; ?>');">
        <h1>Admin Dashboard</h1>
        <nav>
            <ul>
                <li><a href="../index.php">Home</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
    <section>
            <h2>Articles</h2>
            <ul>
            </ul>
        </section>
        <section>
            <h2>Add New Article</h2>
            <form action="articles/add-article.php" method="post">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br><br>
                <label for="image_url">Image Url:</label>
                <input type="text" id="image_url" name="image_url" required><br><br>
                <label for="content">Content:</label>
                <input type="text" id="content" name="content" required><br><br>
               
                <input type="submit" value="Add Article">
            </form>
        </section>
        <section>
            <h2>Team Members</h2>
            <ul>
            <?php while ($team_member = mysqli_fetch_assoc($team_members_result)) { ?>
                    <li>
                        <div>
                            <?php echo $team_member['name']; ?>
                        </div>
                        <div>
                            <?php echo $team_member['position']; ?>
                        </div>
                        <div>
                            <a href="about/edit-member.php?id=<?php echo $team_member['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
                            <a href="about/delete-member.php?id=<?php echo $team_member['id']; ?>"><i class="fas fa-trash-alt"></i> Delete</a>
                        </div>
                    </li>
                <?php } ?>
            </ul>
        </section>
        <section>
            <h2>Add New Team Member</h2>
            <form action="about/add-member.php" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br><br>
                <label for="position">Position:</label>
                <input type="text" id="position" name="position" required><br><br>
               
                <input type="submit" value="Add Team Member">
            </form>
        </section>
        <section>
            <h2>Our Story</h2>
            <ul>
            <?php while ($story = mysqli_fetch_assoc($story_result)) { ?>
                    <li>
                        <div>
                            <?php echo $story['content']; ?>
                        </div>
                        <div>
                            <a href="about/edit-story.php?id=<?php echo $story['id']; ?>"><i class="fas fa-edit"></i> Edit</a>
                        </div>
                    </li>
                <?php } ?>
            </ul>
        </section>
    </main>
</body>




</html>
<?php
// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch tutorials from the database
$tutorials_query = "SELECT * FROM tutorials";
$tutorials_result = mysqli_query($conn, $tutorials_query);

// Fetch articles from the database
$articles_query = "SELECT * FROM articles";
$articles_result = mysqli_query($conn, $articles_query);

// Fetch the background image URL from the database
$background_image_query = "SELECT header_background_image FROM banner WHERE id = 1"; 
$background_image_result = mysqli_query($conn, $background_image_query);
$background_image_row = mysqli_fetch_assoc($background_image_result);
$background_image_url = $background_image_row['header_background_image'];
$banner = array();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<style>
    /* Styles for header */

.admin-header {
    background-size: cover;
    background-position: center;
    color: #fff;
    text-align: center;
    padding: 50px 0;
    box-shadow: inset 0 0 2000px rgba(0, 0, 0, 0.5);
}

.admin-title {
    color: #fff;
    margin-bottom: 10px;
}

.admin-nav {
    margin-top: 10px;
}

.admin-nav a {
    color: #fff;
    text-decoration: none;
    margin-right: 20px;
}


/* Styles for main content */

.admin-main {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.admin-section {
    margin-top: 20px;
}

.admin-heading {
    font-size: 24px;
    margin-bottom: 15px;
}

.admin-list {
    list-style: none;
    padding: 0;
}

.admin-item {
    margin-bottom: 10px;
}

.admin-link {
    color: #007bff;
    text-decoration: none;
    margin-right: 10px;
}


/* Styles for forms */

.admin-form {
    margin-top: 20px;
}

.admin-label {
    font-weight: bold;
}

.admin-input,
.admin-textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

.admin-button {
    background-color: #4f72cb;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.admin-button:hover {
    background-color: #4f72cb;
}
</style>
</head>
<body>

<main class="admin-main">
    <section class="admin-section">
        <h2 class="admin-heading">Tutorials</h2>
        <ul class="admin-list">
            <?php while($tutorial = mysqli_fetch_assoc($tutorials_result)) { ?>
                <li class="admin-item"><?php echo $tutorial['title']; ?> - <a href="tutorials/edit-tutorial.php?id=<?php echo $tutorial['id']; ?>" class="admin-link">Edit</a> | <a href="tutorials/delete-tutorial.php?id=<?php echo $tutorial['id']; ?>" class="admin-link">Delete</a></li>
            <?php } ?>
        </ul>
    </section>

    <section class="admin-section">
    <h2 class="admin-heading">Add New Tutorial</h2>
    <form action="tutorials/add-tutorial.php" method="post" class="admin-form">
        <label for="tutorial_title" class="admin-label">Title:</label><br>
        <input type="text" id="tutorial_title" name="tutorial_title" class="admin-input"><br>
        <label for="tutorial_video_url" class="admin-label">Video URL:</label><br>
        <input type="text" id="tutorial_video_url" name="tutorial_video_url" class="admin-input"><br>
        <input type="submit" value="Submit" class="admin-button">
    </form>
</section>

    <section class="admin-section">
        <h2 class="admin-heading">Articles</h2>
        <ul class="admin-list">
            <?php while($article = mysqli_fetch_assoc($articles_result)) { ?>
                <li class="admin-item"><?php echo substr($article['content'], 0, 100); ?>... - <a href="articles/edit-article.php?id=<?php echo $article['id']; ?>" class="admin-link">Edit</a> | <a href="articles/delete-article.php?id=<?php echo $article['id']; ?>" class="admin-link">Delete</a></li>
            <?php } ?>
        </ul>
    </section>

    <section class="admin-section">
    <h2 class="admin-heading">Add New Article</h2>
    <form action="articles/add-article.php" method="post" class="admin-form">
        <label for="article_title" class="admin-label">Title:</label><br>
        <input type="text" id="article_title" name="article_title" class="admin-input"><br>
        <label for="image_url" class="admin-label">Image URL:</label><br>
        <input type="text" id="image_url" name="image_url" class="admin-input"><br>
        <label for="article_content" class="admin-label">Content:</label><br>
        <textarea id="article_content" name="article_content" rows="4" cols="50" class="admin-textarea"></textarea><br>
        <input type="submit" value="Submit" class="admin-button">
    </form>
    <section class="admin-section">
    <h2 class="admin-heading">Edit Banner Image</h2>
    <form action="edit-banner.php" method="post" class="admin-form">
        <label for="banner_url" class="admin-label">Banner Image URL:</label><br>
        <input type="text" id="banner_url" name="banner_url" value="" class="admin-input"><br>
        <input type="submit" value="Update Banner" class="admin-button">
        <p>Important Update: We've added new features! <a href="#">Learn more</a></p>
    </form>  
</section>
</main>
</body>
</html>










