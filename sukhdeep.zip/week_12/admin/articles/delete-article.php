<?php
// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Delete from database
    $sql = "DELETE FROM articles WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../admin-index.php"); 
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
?>
